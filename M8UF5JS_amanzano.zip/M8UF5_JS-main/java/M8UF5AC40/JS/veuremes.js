function veureMes(){
    document.getElementById('mestext').style.display = 'inline-block';
}