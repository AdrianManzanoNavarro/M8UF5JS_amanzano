function validar(){
    var usuari=document.getElementById("usuari").value;
    var psswd=document.getElementById("psswd").value;
    var confpsswd=document.getElementById("confpsswd").value; 
    if(usuari==""||psswd==""||confpsswd==""){
    alert("L'usuari i els passwords no poden estar en blanc")
    }
    else {
        if(usuari=="Ibai" && psswd=="1234" && confpsswd=="1234"){
            alert("L'usuari i password és correcte")
            return true;
        }
        else {
            alert("No és correcte")
            return false;
        }
    }
}