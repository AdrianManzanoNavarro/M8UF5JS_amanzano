function validar(){
    var nom=document.getElementById("nom").value;
    var psswd=document.getElementById("psswd").value;
    var confpsswd=document.getElementById("confpsswd").value; 
    var nomb=document.getElementById("nomb").value;
    var cognom=document.getElementById("cognom").value;

    if(nom=="" && psswd=="" && confpsswd=="" && nomb=="" && cognom==""){
    alert("El nom, cognom i els passwords no poden estar en blanc")
    }
    else {
        if(psswd==confpsswd){
            alert("El nom i el password és correcte")
        }
        else {
            alert("No és correcte")
        }
    }
}
function guardar(){
    var nomb=document.getElementById("nomb").value;
    var cognom = document.getElementById("cognom").value;
    window.localStorage.setItem("nomb",nomb)
    window.localStorage.setItem("cognom",cognom)
    alert("Les dades han sigut guardades")
    console.log(window.localStorage.getItem("nomb",nomb)+ " *** "+window.localStorage.getItem("cognom",cognom ))
}
function recuperar(){
    var recuperarnom=localStorage.getItem("nomb");
    var recuperarcognom=localStorage.getItem("cognom");
    document.getElementById("nomb").value=recuperarnom
    document.getElementById("cognom").value=recuperarcognom
    alert("Les dades s'han recuperat")
    console.log(window.localStorage.getItem("nomb",nomb)+ " rec "+window.localStorage.getItem("cognom",cognom ))
}
function borrar(){
    localStorage.removeItem("nomb");
    localStorage.removeItem("cognom");
    document.getElementById("nomb").value=""
    document.getElementById("cognom").value=""
    alert("Les dades han sigut borrades")
    
}