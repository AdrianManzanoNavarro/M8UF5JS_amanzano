function encender(element) {
    element.src='img/llumon.gif'
}
function romper(element) {
    element.src='img/llumbreak.gif';
}   
function apagar(element) {
    element.src='img/llumoff.gif'
}
function teclado(element) {
    element.src='img/llumon.gif'
}