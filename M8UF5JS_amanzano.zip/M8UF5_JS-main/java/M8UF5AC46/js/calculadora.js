
function añadir(op) {
    document.getElementById("abc").value+=(op)
}
function borrar() {
    document.getElementById("abc").value=""
}
function opera() {
    var igual=document.getElementById("abc").value
    document.getElementById("abc").value=eval(igual)
}