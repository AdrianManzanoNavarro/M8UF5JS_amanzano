function validar(){
    var psswd=document.getElementById("psswd").value;
    var confpsswd=document.getElementById("confpsswd").value; 
    if(psswd==""||confpsswd==""){
        alert("els passwords no poden estar en blanc")
    }
    else {
        if (psswd == confpsswd){
            alert('Coincideix')
            return true;
        }
        else {
            alert("No coincideix");
            return false;
        }
    } 
}